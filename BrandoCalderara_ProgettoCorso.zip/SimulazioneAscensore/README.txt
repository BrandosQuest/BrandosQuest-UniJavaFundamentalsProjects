Progetto Simulazione Ascensore da parte di Brando Calderara, matr. 746352, consegna individuale.

Creato con IntelliJ IDEA Ultimate 2024.1.b		java 22 SDK

Comprende: diagramma UML, test Junit e commenti javadoc(documentazione già generata) 